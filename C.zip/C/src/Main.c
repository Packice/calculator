#include <stdio.h>
int main()
{
    for(int a ; a = 1000000000 ; )
    {
    printf("第一个数字\n");    
    int two;
    int one;
    //定义变量
    scanf("%d",&one);
    printf("and");
    scanf("%d",&two);
    a = two + one;
    printf("%d\n",a);
    //计算并输出
    }
    return 0;
}
